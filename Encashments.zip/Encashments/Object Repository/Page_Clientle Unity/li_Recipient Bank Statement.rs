<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Recipient Bank Statement</name>
   <tag></tag>
   <elementGuidId>fb958f03-befb-45ce-9e3e-816517bc0f6a</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-repeat</name>
      <type>Main</type>
      <value>doc in encashment.RequiredDocuments</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-class</name>
      <type>Main</type>
      <value>{'text-success':doc.IsSatisfied,'text-danger':!doc.IsSatisfied}</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-binding ng-scope text-danger</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Recipient Bank Statement </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;center-panel&quot;)/div[@class=&quot;row-fluid containerResizer&quot;]/div[@class=&quot;span12 col-md-12 innerContainerResizer&quot;]/div[@class=&quot;innerContainerResizer ng-scope&quot;]/encashment-detail[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[3]/div[@class=&quot;ng-isolate-scope&quot;]/div[@class=&quot;tab-content&quot;]/div[@class=&quot;tab-pane ng-scope active&quot;]/div[@class=&quot;ng-scope&quot;]/div[3]/div[@class=&quot;panel panel-default well col-md-6&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;row&quot;]/ul[1]/li[@class=&quot;ng-binding ng-scope text-danger&quot;]</value>
   </webElementProperties>
</WebElementEntity>
