<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Tasks</name>
   <tag></tag>
   <elementGuidId>dc447dc7-73ac-432a-a2c4-638663dd9748</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>innerContainerResizer ng-scope</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>There was an error loading your content, please contact an administrator. Getting Tasks
    
        
            
                Encashment - E00126353 - (New)
                Encashment Value Summary
            
        
    

    
  
    
  Details

    
  Required Documents

    
  Activity History

    
  Comments

    
  Tasks

        
        
    
  
    
    
            Mark as spot checked
            Send for rework
            Back to Spot Check
            
            
                Cancel Encashment
                Update ID Number
                
            
            
            
            There was an error loading your content, please contact an administrator. Getting Tasks
                
                    
                        Encashment Detail
                    
                    
                        

                            Policy Number
                            
                                612906143
                            
                        
                        
                            First Name
                            
                                
                                    
                                    
                                        Gabene Stanley
                                    
                                
                            
                        
                        
                            Surname
                            
                                
                                    
                                    
                                        Baloyi
                                    
                                
                            
                        
                        
                            FaxNumber
                            
                                
                                    
                                    
                                        Empty
                                    
                                
                            
                        
                        
                            CellNumber
                            
                                
                                    
                                    
                                        0815591750
                                    
                                
                            
                        
                        
                            Email Address
                            
                                
                                    
                                    
                                        cbrown@clientele.co.za
                                    
                                
                            
                        
                        
                            Pay To
                            
                                
                                    
                                    
                                        
                                            Policy Payer
                                        
                                    
                                
                            
                        
                        
                            Encashment Status
                            New
                        

                        
                            Date Encashed
                            31 May 2018 05:43:23 AM
                        
                        
                            Amount To Encash 
                            R 1001.00 of maximum R 4432.64
                        
                        
                            Encashment Payable Less Admin Fees
                            R 700.70
                        
                        
                            Encashment Payable Less Admin Fees
                            R 4432.64
                        
                        
                            Payment Status
                            
                                Funds not yet transferred
                            
                        
                        
                            Encashment Type
                            Partial
                        
                        
                            Cancel Policy
                            
                                
                                    
                                    
                                        No
                                    
                                
                            
                        
                        
                        
                            Required Documents
                            
                                
                                Identity Document 
                            
                        
                    
                
                
                    
                        
                            

    Update Bank Details
    Do AVSR check 
    Do AVSR check 


    
        Bank Detail
    

    
        
        
            Account Type
            Current
        

        
            Account Name
            Gabene Stanley Baloyi
        

        
            Account Number
            371905168
        

        
            Bank Name
            Standard Bank of S.A. Ltd
        

        
            Branch Code
            051001
        

        

    



                        
                        
                    
                    
                        
                        
                            
    
    Update Postal Address

    Postal Address

    

        
            Validated
            Invalid Input
        
        
        
            Address Line 1
            928 TSWELAPELE EXT 5
        

        
            Address Line 2
            WINNIE MANDELA PARK
        

        
            Address Line 3
            TEMBISA
        

        
            Postal Code
            1632
        

    



                        
                    
                
            
        
    
        There was an error loading your content, please contact an administrator. Loading ...
    
    
        
            
                
                    
                        Upload Documents 
                    
                    
                        Required Documents
                        Supporting Documents
                        Add Addtional Required Documents
                    
                
            
            
                
                    
                        Send Documents SMS 
                    
                    
                        Send documents unclear SMS
                        Send documents required SMS
                    
                
            
           Resend Documents
        
    



Required documents

    
        
            Required Document
            Status
            Document Uploaded
            View
            Last Modified
            Rejected Reason
            
            
            
            
        
    
    
        
            Identity Document
            
                

                
                    Pending
                

                
            
            Yes
            View Document
            31 May 2018 06:09:13 AM
            
            
                
                    
                        Actions
                        
                            Verify
                            Reject
                            Copy
                            Delete
                            Move
                        
                    
                
            
            
                
                    
                        Actions
                        
                            Copy
                            Delete
                            Move
                        
                    
                
            
            
                
                    
                        Actions
                        
                            Copy
                        
                    
                
            
            
                Remove
            
        
    



    Previous Document Requirements (deleted)

    
        
            
                Document
                View
                Last Modified
            
        
        
            
        
    



    Documents removed due to bank failure

    
        
            
                Document
                View
                Last Modified
            
        
        
            
        
    



    Additional supporting documents

    
        
            
                Document
                View
                Last Modified
            
        
        
            
        
    


    
    
        There was an error loading your content, please contact an administrator. Loading ...
    

        .avsrstatus {
            color: maroon;
        }

        .avsr-ok {
			background-color: #3a87ad;
		}
		
		.avsr-nok {
			background-color: #b94a48;
		}
		
		.avsr-pending {
			background-color: #f89406;
		}
		
		.avsr {
			padding: 1px 4px 2px;
			font-size: 10.998px;
			font-weight: bold;
			line-height: 13px;
			color: #ffffff;
			vertical-align: middle;
			white-space: nowrap;
			text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
			-moz-border-radius: 3px;
			border-radius: 3px;
            font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;
		}

    
    
    
        
            
                Date
                Action
                Modified By
            
        
        
            
                31 May 2018 06:09:13 AM
                Required Document Uploaded  - Identity Document
                
                clientele\CBrown
            
                31 May 2018 05:43:30 AM
                
                Encashment Value Configuration Updated
                clientele\CBrown
            
                31 May 2018 05:43:23 AM
                
                Value Requested
                clientele\CBrown
            
                31 May 2018 05:43:23 AM
                
                Encashment Requested
                clientele\CBrown
            
                31 May 2018 05:43:23 AM
                Required Document Added  - Identity Document
                
                clientele\CBrown
            
        
    

    
    
        

    
        Add Comment
    




There was an error loading your content, please contact an administrator. There are no comments

    
        
            
                
                    
                        Date
                        Comment
                        User
                    
                
                
                    
                
            
        
    

    
    
        There are no active tasks
        
            
            
                Currently Active Tasks
            
            
            
        

    
  


</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;center-panel&quot;)/div[@class=&quot;row-fluid containerResizer&quot;]/div[@class=&quot;span12 col-md-12 innerContainerResizer&quot;]/div[@class=&quot;innerContainerResizer ng-scope&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-show</name>
      <type>Main</type>
      <value>ShowTasks</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>heading</name>
      <type>Main</type>
      <value>Tasks</value>
   </webElementProperties>
</WebElementEntity>
