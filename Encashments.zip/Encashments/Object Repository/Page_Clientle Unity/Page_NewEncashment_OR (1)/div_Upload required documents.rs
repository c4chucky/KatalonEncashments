<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Upload required documents</name>
   <tag></tag>
   <elementGuidId>33487c07-2ae1-4f4e-bec0-84e4449b05d6</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-scope</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        Upload required documents
   
        Please select which requirements the document being attached satisfies.
        
            File
            
                
                    
                
            
            Matching Requirements
            
                
                    
                        Requirement
                    
                    
                        
                    
                
                
                    
                        Identity Document
                    
                    
                

            

        
        
            Cancel
            Save

        
    
</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ng-app&quot;)/body[@class=&quot;modal-open&quot;]/div[@class=&quot;modal fade app-modal-window modal- in&quot;]/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;ng-scope&quot;]</value>
   </webElementProperties>
</WebElementEntity>
