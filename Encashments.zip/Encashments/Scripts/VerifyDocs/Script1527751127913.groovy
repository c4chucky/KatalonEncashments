import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.junit.After as After
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.setText(findTestObject('Object Repository/Page_Clientle Unity/input_SearchBox'), GlobalVariable.EncashmentNo)

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/button_Go'))

WebUI.waitForElementVisible(findTestObject('Object Repository/Page_Clientle Unity/Page_EncashmentsRequiredDocs_OR/a_Tasks'), 
    GlobalVariable.TimeOut)

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/Page_EncashmentsRequiredDocs_OR/a_Tasks'))

WebUI.waitForAngularLoad(GlobalVariable.TimeOut)

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_ActiveTask'), GlobalVariable.TimeOut)

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_ActiveTask'))

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_Tasks'))

WebUI.waitForAngularLoad(GlobalVariable.TimeOut)

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/Page_EncashmentsRequiredDocs_OR/a_HeaderTask'))

WebUI.waitForAngularLoad(GlobalVariable.TimeOut)

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_ClaimTask'))

WebUI.waitForAngularLoad(GlobalVariable.TimeOut)

WebUI.waitForElementVisible(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_Required Documents'), 
    GlobalVariable.TimeOut)

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_Required Documents'))

WebUI.waitForElementVisible(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_Actions'), GlobalVariable.TimeOut)

WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_Actions'), GlobalVariable.TimeOut)

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_Actions'))

WebUI.waitForAngularLoad(GlobalVariable.TimeOut)

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/a_Verify'))

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/a_Details'))

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Clientle Unity/h4_Required Documents'), GlobalVariable.TimeOut)

WebUI.takeScreenshot()

