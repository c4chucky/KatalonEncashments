import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import java.awt.TexturePaintContext.Int as Int
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.sun.org.apache.xalan.internal.xsltc.compiler.If as If
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.apache.commons.lang3.SystemUtils as SystemUtils
import org.junit.After as After
import org.openqa.selenium.Keys as Keys
import org.stringtemplate.v4.compiler.STParser.notConditional_return as notConditional_return

//def row = 12
WebUI.callTestCase(findTestCase('EncashmentLogins/LoginCBrown'), [:], FailureHandling.STOP_ON_FAILURE)

//for (GlobalVariable.row; GlobalVariable.row <= GlobalVariable.NumberOfEncashments; GlobalVariable.row++) {
String baseURL = 'http://unitytest.clientele.local/#/Encashments/'

WebUI.navigateToUrl(baseURL)

WebUI.waitForPageLoad(GlobalVariable.TimeOut)

WebUI.verifyElementPresent(findTestObject('Page_Clientle Unity/h1_Clientle Encashments Search'), GlobalVariable.TimeOut)

//WebUI.click(findTestObject('Page_Clientle Unity/label_Search'))
WebUI.setText(findTestObject('Page_Clientle Unity/input_stdPolicySearchSearchTex'), findTestData('EncashmentPolicies').getValue(
        'PolicyNo', GlobalVariable.row))

WebUI.click(findTestObject('Page_Clientle Unity/button_Search'))

WebUI.click(findTestObject('Object Repository/Page_Clientle Unity/a_Details'))

WebUI.takeScreenshot()

WebUI.waitForElementVisible(findTestObject('Page_Clientle Unity/a_Get Value'), GlobalVariable.TimeOut)

WebUI.click(findTestObject('Page_Clientle Unity/a_Get Value'))

WebUI.takeScreenshot()

def div_ValueRequestErrorMessage = findTestObject('Object Repository/Page_Clientle Unity/div_ValueRequestErrorMessage')

def button_CreateEncashment = findTestObject('Page_Clientle Unity/button_Create Encashment')

/*
	if (WebUI.verifyElementPresent(button_CreateEncashment, 10) == null) {
		def EncashErrorText = WebUI.getText(div_ValueRequestErrorMessage)
		println (GlobalVariable.row + " -------------------- " + EncashErrorText + " ----------------------")
		CustomKeywords.'myPack.WriteExcel.demoKey'(EncashErrorText)
		return
		//continue
		}
	
//}
*/
WebUI.waitForElementVisible(findTestObject('Page_Clientle Unity/button_Create Encashment'), GlobalVariable.TimeOut)

WebUI.click(findTestObject('Page_Clientle Unity/button_Create Encashment'))

WebUI.takeScreenshot()

/*
	WebUI.waitForElementClickable(findTestObject('Page_Clientle Unity/h2_Create Encashment For - 400'), 15)
	
	WebUI.click(findTestObject('Page_Clientle Unity/h2_Create Encashment For - 400'))
*/
WebUI.waitForAngularLoad(GlobalVariable.TimeOut)

WebUI.waitForElementVisible(findTestObject('Page_Clientle Unity/label_Pay To'), GlobalVariable.TimeOut)

WebUI.click(findTestObject('Page_Clientle Unity/label_Pay To'))

WebUI.click(findTestObject('Page_Clientle Unity/select_PayTo'))

WebUI.selectOptionByLabel(findTestObject('Page_Clientle Unity/select_PayTo'), findTestData('EncashmentPolicies').getValue(
        'PayTo', GlobalVariable.row), false)

WebUI.setText(findTestObject('Page_Clientle Unity/input_Email'), findTestData('EncashmentPolicies').getValue('Email', GlobalVariable.row))

WebUI.setText(findTestObject('Page_Clientle Unity/input_CellNumber'), findTestData('EncashmentPolicies').getValue('Cell', 
        GlobalVariable.row))

//Get Available Encashments amount from the page.
String EncashAvailableAmnt = WebUI.getText(findTestObject('Object Repository/Page_Clientle Unity/Page_NewEncashment_OR/label_AvailableAmount'))

println(('--------------------' + EncashAvailableAmnt) + '--------------------')

//Split the string to find the actual amount
String[] SplitString = EncashAvailableAmnt.split(' ')

println(SplitString)

//Convert the amounts to double
double last = ((SplitString[(SplitString.length - 1)]) as double)

double encashValue = ((findTestData('EncashmentPolicies').getValue('encashAmount', GlobalVariable.row)) as double)

//Convert back to string in order to set text
String AvailableEncashmentAmount = last.toString()

String encashAmnt = encashValue.toString()

// Check if the available amount is less than the excel sheet amount. Then only put the available amount.
if (last < encashValue) {
    WebUI.setText(findTestObject('Page_Clientle Unity/input_encashAmount'), AvailableEncashmentAmount)
} else {
    WebUI.setText(findTestObject('Page_Clientle Unity/input_encashAmount'), encashAmnt)
}

WebUI.click(findTestObject('Page_Clientle Unity/label_Reason'))

WebUI.selectOptionByValue(findTestObject('Page_Clientle Unity/select_Reason'), '0', true)

WebUI.click(findTestObject('Page_Clientle Unity/button_Save'))

//WebUI.waitForAngularLoad(GlobalVariable.TimeOut)
WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Clientle Unity/h2_Encashment - (New)'), GlobalVariable.TimeOut)

String NewEncashment = WebUI.getText(findTestObject('Object Repository/Page_Clientle Unity/h2_Encashment - (New)'))

println(('---------------' + NewEncashment) + '-------------------')

String[] SplitEncashNo = NewEncashment.split(' - ')

println(('---------------' + SplitEncashNo) + '-------------------')

GlobalVariable.EncashmentNo = (SplitEncashNo[(SplitEncashNo.length - 1)])

println(('---------------' + GlobalVariable.EncashmentNo) + '-------------------')

CustomKeywords.'myPack.WriteExcel.demoKey'(GlobalVariable.EncashmentNo)

WebUI.takeScreenshot()

WebUI.waitForPageLoad(GlobalVariable.TimeOut)

