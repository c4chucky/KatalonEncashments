<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_you are logged in with</name>
   <tag></tag>
   <elementGuidId>05077e56-e7e8-4793-adbe-4e88bc09805c</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>row-fluid containerResizer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                    
                          you are logged in with:  
                    
                

                
                    
                    There was an error loading your content, please contact an administrator. Loading ...
    
    
        
            
                Policy Information - 400831200
            
        
    

    
        
            
  
                
  Policy Summary

                
  Policy Benefits

                
  Encashment History

                
  Accounting History

                
  Policy Individuals

                
  Value Request History

                
  Get Value

            
  
    
    There was an error loading your content, please contact an administrator. Loading ...
    
        
            
                Product Description
                Master Contract Number
                Plan Code
                Product Code
                Product Status
                Capture Date
                DOC
            
        
        
            
                Classic Saver Endowment Plan
                0050
                CC01
                CC
                Active
                23 February 2002
                28 February 2002
            
        
    


    There was an error loading your content, please contact an administrator. 
    
        
            
                Date Of Commencement
                Plan Code
                Plan Description
                Status
                Sum Assured
            
        
        
            
        
    


    
    Encashments

There was an error loading your content, please contact an administrator. There are no encashments
    
        
            
                Encashment Number
                First Name
                Surname
                Amount to Encash
                Full Encashment
                Cancel Policy
                Created Date
                
            
        
        
            
        
    



    Telenet Encashments

There was an error loading your content, please contact an administrator. 
    There are no legacy encashments
    
        
            
                Date
                Amount
            
        
        
            
        
    




    
There was an error loading your content, please contact an administrator. 
    
        
            Total Months Paid
            
                
            
        
        
            Total Premiums Paid
            
                R NaN
            
        
    
    
        
            
                
                    Applicable Month
                    Payment Status
                    Transactions
                    Amount
                
            
            
                
            
        
    
    


    
  Previous1Next





    There was an error loading your content, please contact an administrator. 
    
        
            
                Date Of Birth
                First Names
                Surname
                Id Number
                Passport
                Type
            
        
        
            
        
    

    There was an error loading your content, please contact an administrator. There are no value requests
    
        
        
            User
            Value Request Date
            Surrender Value
        
        
        
        
        
    


    There was an error loading your content, please contact an administrator. Loading ...
    
        
            
                
                    Create Encashment For - 400831200
                    
                        
                            
                                
                                    Create Encashment
                                
                            
                        
                        Encashment Value Summary
                    
                
                
                    
                        There is currently a manual calculation being done on this policy and is unavailable for encashing.
                        Please advise the customer that they will be notified as soon as it is completed.
                    
                
            
            
                
                
                    The Client can Encash on this policy again on .
                
                
                    
                        Please advise the client that additional calculations need to be done on their investment and we are initiating the calculation on their behalf.
                        Initiate Manual Calculation
                    
                
            
            
                
                    
                        Create Encashment For - 400831200
                    

                    
                        This policy is scheduled for cancellation, or is already cancelled. No further encashments can be created.
                    
                    
                        If a customer wishes to encash, please inform them encashment   is currently in .
                        
                        If they wish to change values, please edit the encashment.
                    
                
                
                    There has been an encashment in the last 5 years, therefore no encashment can be created.
                    The Client can Encash on this policy again on .
                
                
                    This policy has a cancelled status. No further encashments can be created.
                
                
                    This policy is in Active status.
                
            
        

    
    
        
            
                Value Detail
                Request Manual Calculation
                
            
            
                
                    Policy Status
                    Active
                
                
                    Date Of Commencement
                    28 February 2002
                
                
                    Date Of Reinstatement
                    
                
                
                    Premiums Paid
                    195
                
                
                    Current Surrender Factor %
                    100%
                
                
                    Next Surrender Factor %
                    100%
                
                
                    Remaining premiums to next bracket
                    0
                
                
                    Premium Percentage Brackets
                
                
                    
                        
                            
                                
                                    First premium
                                    Last Premium
                                    Value available
                                
                            
                            
                                
                                    1
                                    
                                        119
                                        1+
                                    
                                    
                                        60%
                                    
                                
                                    120
                                    
                                        2147483647
                                        120+
                                    
                                    
                                        100%
                                    
                                
                            
                        
                    
                
                
                    Premiums Paid Value
                    R 22254.24
                
                
                    Death Surrender Value
                    R 11260.95
                

                
                    Encashment Value
                    R 10940.52
                
                
                
                    
                        
                            Ordinary Units
                            2408.027
                        
                        
                            Paid Up Units
                            0
                        
                        
                            Unit Price After Adjustment
                            R 4.68
                        
                        
                            Encashment Admin Fee
                            R 500.00
                        
                        
                            Paid Up Admin Fee
                            R 0.00
                        
                        
                            Paid Up Encashment Fee
                            R 0.00
                        
                        
                            Unallocated Premiums Value
                            R 179.57
                        
                    
                
                
                    Last Premium Received
                    R 229.68
                
                
                    Last Allocated Date
                    08 May 2018
                
                
                    Unallocated Premiums
                    
                        
                        
                            
                                
                                    Date
                                
                            
                            
                                
                                    30 April 2018
                                
                            
                        
                    
                
                
                    Annual Increase Percent
                    10%
                
                
                
                    Previous Encashments
                    
                        

                        
                            
                                
                                    Date
                                    Value
                                
                            

                            
                                
                                    
                                        Previous Encashment Total
                                    
                                    
                                        R -10377.86
                                    
                                
                                
                                    14 February 2012
                                    R -10377.86
                                
                            
                        
                    
                
            
        
    
    There was an error loading your content, please contact an administrator. Loading ...
    
        There seems to be an issue retrieving last updated bank details, please contact an administrator.
    
    
        

            

                
                    Available Amount: R 10940.52
                

                

                    

                        
                            Is Payer Deceased 
                            
                                
                            
                        
                        
                            Is Legal Entity 
                            
                                
                            
                        

                        
                            First Name
                            
                                
                                First name is required
                                Please enter valid first name
                            
                        

                        
                            Surname
                            
                                
                                Surname is required
                                Please enter valid surname
                            
                        

                        
                            Pay To
                            
                                Please SelectPolicy PayerAlternate Account3rd Party
                                Please select who should be paid
                            
                        

                        
                            Email For Forms
                            
                                
                                Please enter valid email address
                            
                        

                        
                            
                                OR
                            
                        

                        
                            Fax For Forms
                            
                                
                                Please enter valid fax number
                                Fax number must be a length of 10
                            
                        

                        
                            Cell Number
                            
                                
                                Cell number is required
                                Please enter valid cell phone number
                                Cell number must be a length of 10
                            
                        

                        
                            Encash Full Amount
                            
                                
                            
                        

                        
                            Partial Encashment Amount
                            
                                
                                Amount is required
                                Please enter valid amount
                                Amount to encash cant be higher than available amount
                            
                        

                        
                            Reason
                            
                                Please SelectFinancial ReasonsBenefitsServiceConditions - Terms of the PolicyAlternative ProductDisputeReason Not GivenOther
                                Please select reason
                            
                        

                        
                            Other
                            
                                
                                Other is required when you choose other from drop down
                            
                        

                        
                            Cancel Policy
                            
                                
                            
                        
                    
                
            

        
        
            

    Update Bank Details
    Do AVSR check 
    Do AVSR check 


    
        Bank Detail
    

    
        
        
            Account Type
            Cheque Account
        

        
            Account Name
            M Molete 
        

        
            Account Number
            022733191
        

        
            Bank Name
            Standard Bank of S.A. Ltd
        

        
            Branch Code
            051001
        

        

    



            
    
    Update Postal Address

    Postal Address

    

        
            Validated
            No
        
        
        
            Address Line 1
            15653
        

        
            Address Line 2
            DAVEYTON EXT 3
        

        
            Address Line 3
            
        

        
            Postal Code
            1520
        

    



        

        
            
                
                    Required Fields:
                    
                        First Name
                        Surname
                        Select Whom To Pay
                        Email address OR Fax number Or Validated Postal Address
                        Cell Number
                        Encashment Amount
                        Encashment Reason
                    
                
                
                    Save
                    Cancel
                
            
        
    





  

        
        
    


                
            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;center-panel&quot;)/div[@class=&quot;row-fluid containerResizer&quot;]</value>
   </webElementProperties>
</WebElementEntity>
