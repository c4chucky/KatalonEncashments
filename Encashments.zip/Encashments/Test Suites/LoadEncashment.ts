<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>LoadEncashment</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-06-11T10:21:28</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>2</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>79098844-203d-4d77-a0b8-29866134450e</testSuiteGuid>
   <testCaseLink>
      <guid>08fc16cd-66ef-4dbe-853a-80c54d2dff96</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EncashmentLogins/LoginEncashmentsCallCentreAgent</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d110a00d-704d-44e0-ba70-2579f32bc5b0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/LoadNewEncashment</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
