<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Search Results</name>
   <tag></tag>
   <elementGuidId>739b0c05-99cd-43cf-a3e6-f8267188bab8</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Search Results</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;center-panel&quot;)/div[@class=&quot;row-fluid containerResizer&quot;]/div[@class=&quot;span12 col-md-12 innerContainerResizer&quot;]/div[@class=&quot;innerContainerResizer ng-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[3]/div[2]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;panel panel-default ng-scope&quot;]/div[@class=&quot;panel-heading&quot;]/h2[1]</value>
   </webElementProperties>
</WebElementEntity>
