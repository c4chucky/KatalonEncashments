<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_you are logged in with    _1</name>
   <tag></tag>
   <elementGuidId>21cfcd4d-5554-4045-bc31-4f05efcb59de</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>row-fluid containerResizer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                    
                          you are logged in with:  
                    
                

                
                    
                    There was an error loading your content, please contact an administrator. Loading ...
    
        
            
                Encashment - E00126351 - (New)
                Encashment Value Summary
            
        
    

    
  
    
  Details

    
  Required Documents

    
  Activity History

    
  Comments

    
  Tasks

        
        
    
  
    
    
            Mark as spot checked
            Send for rework
            Back to Spot Check
            
            
                Cancel Encashment
                Update ID Number
                
            
            
            
            There was an error loading your content, please contact an administrator. Loading ...
                
                    
                        Encashment Detail
                    
                    
                        

                            Policy Number
                            
                                400831200
                            
                        
                        
                            First Name
                            
                                
                                    
                                    
                                        Magdelina
                                    
                                
                            
                        
                        
                            Surname
                            
                                
                                    
                                    
                                        Molete
                                    
                                
                            
                        
                        
                            FaxNumber
                            
                                
                                    
                                    
                                        Empty
                                    
                                
                            
                        
                        
                            CellNumber
                            
                                
                                    
                                    
                                        0815591750
                                    
                                
                            
                        
                        
                            Email Address
                            
                                
                                    
                                    
                                        cbrown@clientele.co.za
                                    
                                
                            
                        
                        
                            Pay To
                            
                                
                                    
                                    
                                        
                                            Alternate Account
                                        
                                    
                                
                            
                        
                        
                            Encashment Status
                            New
                        

                        
                            Date Encashed
                            30 May 2018 08:25:55 AM
                        
                        
                            Amount To Encash 
                            R 4000.00 of maximum R 10940.52
                        
                        
                            Encashment Payable Less Admin Fees
                            R 3500.00
                        
                        
                            Encashment Payable Less Admin Fees
                            R 10940.52
                        
                        
                            Payment Status
                            
                                Funds not yet transferred
                            
                        
                        
                            Encashment Type
                            Partial
                        
                        
                            Cancel Policy
                            
                                
                                    
                                    
                                        No
                                    
                                
                            
                        
                        
                        
                            Required Documents
                            
                                
                                Signed Encashment Form Recipient Bank Statement Certified Policy Payer Identity Document 
                            
                        
                    
                
                
                    
                        
                        
                            

    Update Bank Details
    Do AVSR check 
    Do AVSR check 


    
        Bank Detail
    

    
        
        
            Account Type
            
        

        
            Account Name
            
        

        
            Account Number
            
        

        
            Bank Name
            
        

        
            Branch Code
            
        

        

    



                        
                    
                    
                        
                        
                            
    
    Update Postal Address

    Postal Address

    

        
            Validated
            Invalid Input
        
        
        
            Address Line 1
            15653
        

        
            Address Line 2
            DAVEYTON EXT 3
        

        
            Address Line 3
            
        

        
            Postal Code
            1520
        

    



                        
                    
                
            
        
    
        There was an error loading your content, please contact an administrator. 
    
    
        
            
                
                    
                        Upload Documents 
                    
                    
                        Required Documents
                        Supporting Documents
                        Add Addtional Required Documents
                    
                
            
            
                
                    
                        Send Documents SMS 
                    
                    
                        Send documents unclear SMS
                        Send documents required SMS
                    
                
            
           Resend Documents
        
    



Required documents

    
        
            Required Document
            Status
            Document Uploaded
            View
            Last Modified
            Rejected Reason
            
            
            
            
        
    
    
        
    



    Previous Document Requirements (deleted)

    
        
            
                Document
                View
                Last Modified
            
        
        
            
        
    



    Documents removed due to bank failure

    
        
            
                Document
                View
                Last Modified
            
        
        
            
        
    



    Additional supporting documents

    
        
            
                Document
                View
                Last Modified
            
        
        
            
        
    


    
    
        There was an error loading your content, please contact an administrator. 
    

        .avsrstatus {
            color: maroon;
        }

        .avsr-ok {
			background-color: #3a87ad;
		}
		
		.avsr-nok {
			background-color: #b94a48;
		}
		
		.avsr-pending {
			background-color: #f89406;
		}
		
		.avsr {
			padding: 1px 4px 2px;
			font-size: 10.998px;
			font-weight: bold;
			line-height: 13px;
			color: #ffffff;
			vertical-align: middle;
			white-space: nowrap;
			text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
			-moz-border-radius: 3px;
			border-radius: 3px;
            font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;
		}

    
    
    
        
            
                Date
                Action
                Modified By
            
        
        
            
        
    

    
    
        

    
        Add Comment
    




There was an error loading your content, please contact an administrator. There are no comments

    
        
            
                
                    
                        Date
                        Comment
                        User
                    
                
                
                    
                
            
        
    

    
    
        There are no active tasks
        
            
            
                Currently Active Tasks
            
            
            
        

    
  



                
            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;center-panel&quot;)/div[@class=&quot;row-fluid containerResizer&quot;]</value>
   </webElementProperties>
</WebElementEntity>
