<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Create Encashment</name>
   <tag></tag>
   <elementGuidId>69af2f85-400f-4fcc-b546-bc3f33ea2fe1</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-show</name>
      <type>Main</type>
      <value>!showCreateEncashment &amp;&amp; encashmentValue.PaymentSurrenderValue > 0 &amp;&amp; !manualCalculationInProgress &amp;&amp; !encashmentInLast5Years</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-click</name>
      <type>Main</type>
      <value>createEncashment()</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Create Encashment</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;center-panel&quot;)/div[@class=&quot;row-fluid containerResizer&quot;]/div[@class=&quot;span12 col-md-12 innerContainerResizer&quot;]/div[@class=&quot;innerContainerResizer ng-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[3]/div[2]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;ng-isolate-scope&quot;]/div[@class=&quot;tab-content&quot;]/div[@class=&quot;tab-pane ng-scope active&quot;]/value-request-for-policy[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[3]/div[@class=&quot;panel panel-default&quot;]/div[@class=&quot;panel-heading&quot;]/div[1]/h2[@class=&quot;ng-binding&quot;]/div[@class=&quot;btn-toolbar pull-right&quot;]/authorise-access[@class=&quot;ng-isolate-scope&quot;]/div[1]/div[1]/button[@class=&quot;btn btn-primary&quot;]</value>
   </webElementProperties>
</WebElementEntity>
