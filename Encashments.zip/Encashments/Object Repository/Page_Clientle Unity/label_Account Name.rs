<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Account Name</name>
   <tag></tag>
   <elementGuidId>0e0e3dbd-b995-490f-bb30-4b19c5fd5316</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-md-4</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Account Name</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;center-panel&quot;)/div[@class=&quot;row-fluid containerResizer&quot;]/div[@class=&quot;span12 col-md-12 innerContainerResizer&quot;]/div[@class=&quot;innerContainerResizer ng-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[3]/div[2]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;ng-isolate-scope&quot;]/div[@class=&quot;tab-content&quot;]/div[@class=&quot;tab-pane ng-scope active&quot;]/value-request-for-policy[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[3]/create-encashment[@class=&quot;ng-isolate-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[3]/div[2]/div[@class=&quot;col-md-6&quot;]/unity-bank-detail-view[@class=&quot;ng-isolate-scope&quot;]/div[@class=&quot;panel panel-default well&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;row&quot;]/label[@class=&quot;col-md-4&quot;]</value>
   </webElementProperties>
</WebElementEntity>
