
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String


def static "myPack.WriteExcel.demoKey"(
    	String name	) {
    (new myPack.WriteExcel()).demoKey(
        	name)
}
