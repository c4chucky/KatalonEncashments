<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>BankValREST</name>
   <tag></tag>
   <elementGuidId>bf185639-67ba-4a92-b05b-854f542f7b96</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n    \&quot;AccountNumber\&quot;: \&quot;1405728858\&quot;,\n    \&quot;BranchCode\&quot;: \&quot;470010\&quot;,\n    \&quot;AccountType\&quot;: \&quot;Savings\&quot;,\n    \&quot;BankName\&quot;: \&quot;Capitec Bank Ltd\&quot;,\n    \&quot;BankValidationOptions\&quot;: {\n        \&quot;SourceSystemId\&quot;: \&quot;0A4BBD3F-8DF7-49AF-979A-2AA5E76A946B\&quot;,\n        \&quot;IsLegal\&quot;: false,\n        \&quot;IdentityOrPassportOrRegistrationNumber\&quot;: \&quot;6808240364083\&quot;,\n        \&quot;Initials\&quot;: \&quot;MJ\&quot;,\n        \&quot;SurnameOrCompanyName\&quot;: \&quot;Julia\&quot;,\n        \&quot;BusinessEntity\&quot;: \&quot;ThirdParty\&quot;,\n        \&quot;ValidateSoftyComp\&quot;: true,\n        \&quot;ValidateFraudster\&quot;: true,\n        \&quot;ValidateD3BlackList\&quot;: true,\n        \&quot;ValidateAvsr\&quot;: true,\n        \&quot;FraudsterRejectionCodesToIgnore\&quot;: [4,32,34,36,7101],\n        \&quot;AvsrBanksToIgnore\&quot;: [],\n        \&quot;TimeoutInSeconds\&quot;: 30\n    }\n}\n&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>http://bankvalidationapitest.clientele.local/api/BankValidation/AccountValidation?</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
